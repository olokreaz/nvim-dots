-- Options are automatically loaded before lazy.nvim startup
-- Default options that are always set: https://github.com/LazyVim/LazyVim/blob/main/lua/lazyvim/config/options.lua
-- Add any additional options here

-- Обычные настройки табуляции/отступов
vim.o.tabstop = 4
vim.o.shiftwidth = 4
vim.o.softtabstop = 4
vim.o.expandtab = false

-- Рекомендованные дополнительные опции
vim.o.smarttab = true
vim.o.autoindent = true
vim.o.smartindent = true

vim.opt.spelllang = { "en", "ru" }

-- vim.o.background = 'light'
