function translate_to_ru(output_type)
    return function()
        require("translate").translate({
            get_command = function(input)
                return {
                    "trans",
                    "-e",
                    "google",
                    "-b",
                    ":ru",
                    input,
                }
            end,
            -- input | clipboard | selection
            input = "selection",
            -- open_float | notify | copy | insert | replace
            output = { output_type },
            resolve_result = function(result)
                if result.code ~= 0 then
                    return nil
                end

                return string.match(result.stdout, "(.*)\n")
            end,
        })
    end
end

if true then
    return {
        {
            "baliestri/aura-theme",
            lazy = false,
            priority = 1000,
            config = function(plugin)
                -- vim.opt.rtp:append(plugin.dir .. "/packages/neovim")
                -- vim.cmd([[colorscheme aura-dark]])
            end,
        },
        {
            "T-b-t-nchos/Aquavium.nvim",
            lazy = false,
            priority = 1000,
            config = function()
                local aquavium = require("Aquavium")

                aquavium.setup({
                    -- your options here
                })

                -- vim.cmd("colorscheme Aquavium")
            end,
        },
        {
            "0xstepit/flow.nvim",
            lazy = false,
            priority = 1000,
            -- tag = "v2.0.1",
            opts = {
                theme = {
                    style = "dark", --  "dark" | "light"
                    contrast = "high", -- "default" | "high"
                    transparent = true, -- true | false
                },
                colors = {
                    mode = "default", -- "default" | "dark" | "light"
                    fluo = "pink", -- "pink" | "cyan" | "yellow" | "orange" | "green"
                    custom = {
                        saturation = "100", -- "" | string representing an integer between 0 and 100
                        -- light = "100", -- "" | string representing an integer between 0 and 100
                    },
                },
                ui = {
                    borders = "dark", -- "light" | "dark" | "none"
                    aggressive_spell = true, -- true | false
                },
            },
            config = function(_, opts)
                require("flow").setup(opts)
                -- vim.cmd("colorscheme flow")
            end,
        },
        {
            "tk4n9/bw.nvim",
            config = function()
                -- Optional: setup options
                require("bw").setup({
                    bold = true,
                    italic = true,
                })

                -- Load a theme
                -- vim.cmd.colorscheme("bw-grayscale")
                -- or
                -- vim.cmd.colorscheme("bw-binary")
            end,
        },
        {
            "olimorris/codecompanion.nvim",
            config = function()
                require("codecompanion").setup({
                    adapters = {
                        http = {
                            ollama = function()
                                return require("codecompanion.adapters").extend("ollama", {
                                    env = {
                                        url = "http://92.100.194.113:11434",
                                    },
                                    schema = {
                                        model = {
                                            default = "qwen2.5-coder:7b",
                                        },
                                    },
                                })
                            end,
                        },
                    },
                    strategies = {
                        chat = { adapter = "ollama" }, -- чат‑режим
                        inline = { adapter = "ollama" }, -- inline‑подсказки
                    },
                })
            end,
        },
        -- {
        --     "mfussenegger/nvim-dap",
        --     config = function()
        --         local dap = require("dap")
        --
        --         -- Конфигурация адаптера LLVM DAP (LLDB)
        --         dap.adapters.lldb = {
        --             type = "executable",
        --             command = "lldb-dap", -- укажите полный путь, если нужно
        --             name = "lldb",
        --         }
        --
        --         -- Расширенная конфигурация для C/C++
        --         dap.configurations.cpp = {
        --
        --             -- 1. Запуск с параметрами
        --             {
        --                 name = "Launch with args (llvm-dap)",
        --                 type = "lldb",
        --                 request = "launch",
        --                 program = function()
        --                     return vim.fn.input("Path to executable: ", vim.fn.getcwd() .. "/", "file")
        --                 end,
        --                 args = function()
        --                     -- Запрос аргументов у пользователя
        --                     local input = vim.fn.input("Program arguments (space-separated): ")
        --                     if input == "" then
        --                         return {}
        --                     end
        --                     -- Разбиваем строку на массив аргументов
        --                     return vim.split(input, " ", { trimempty = true })
        --                 end,
        --                 cwd = "${workspaceFolder}",
        --                 stopOnEntry = false,
        --                 runInTerminal = false, -- true для запуска в терминале
        --                 -- env = function()
        --                 --     -- Опционально: запрос переменных окружения
        --                 --     local env_input = vim.fn.input("Environment variables (KEY=VALUE, space-separated): ")
        --                 --     if env_input == "" then
        --                 --         return nil
        --                 --     end
        --                 --     local env = {}
        --                 --     for pair in string.gmatch(env_input, "[^ ]+") do
        --                 --         local key, value = string.match(pair, "(%w+)=(.*)")
        --                 --         if key and value then
        --                 --             env[key] = value
        --                 --         end
        --                 --     end
        --                 --     return env
        --                 -- end,
        --             },
        --
        --             -- 2. Подключение к существующему процессу (по PID)
        --             {
        --                 name = "Attach to process (PID)",
        --                 type = "lldb",
        --                 request = "attach",
        --                 program = function()
        --                     return vim.fn.input("Path to executable (for symbols): ", vim.fn.getcwd() .. "/", "file")
        --                 end,
        --                 pid = function()
        --                     -- Используем встроенную утилиту nvim-dap для выбора процесса
        --                     return require("dap.utils").pick_process()
        --                 end,
        --                 cwd = "${workspaceFolder}",
        --             },
        --
        --             -- 3. Подключение к lldbserver (удаленная отладка)
        --             {
        --                 name = "Connect to lldbserver",
        --                 type = "lldb",
        --                 request = "attach",
        --                 -- Указываем адрес сервера в формате host:port
        --                 target = function()
        --                     local host = vim.fn.input("lldbserver host (default: localhost): ", "localhost")
        --                     local port = vim.fn.input("lldbserver port (default: 1234): ", "1234")
        --                     return host .. ":" .. port
        --                 end,
        --                 program = function()
        --                     return vim.fn.input("Path to local executable (for symbols): ", vim.fn.getcwd() .. "/", "file")
        --                 end,
        --                 cwd = "${workspaceFolder}",
        --                 -- Ключевой параметр для удалённой отладки
        --                 connectURL = function(config)
        --                     return "connect://" .. config.target
        --                 end,
        --             },
        --         }
        --
        --         -- Копируем конфигурации для C
        --         dap.configurations.c = dap.configurations.cpp
        --
        --         -- Горячие клавиши (можно оставить из предыдущего примера)
        --         vim.keymap.set("n", "<F5>", dap.continue, { desc = "DAP: Continue" })
        --         vim.keymap.set("n", "<F10>", dap.step_over, { desc = "DAP: Step Over" })
        --         vim.keymap.set("n", "<F11>", dap.step_into, { desc = "DAP: Step Into" })
        --         vim.keymap.set("n", "<F12>", dap.step_out, { desc = "DAP: Step Out" })
        --         -- vim.keymap.set("n", "<leader>db", dap.toggle_breakpoint, { desc = "DAP: Toggle Breakpoint" })
        --         -- vim.keymap.set("n", "<leader>dr", dap.run_to_cursor, { desc = "DAP: Run to Cursor" })
        --         -- vim.keymap.set("n", "<leader>dl", function()
        --         --     dap.repl.open()
        --         -- end, { desc = "DAP: Open REPL" })
        --         -- vim.keymap.set("n", "<leader>dk", function()
        --         --     require("dapui").toggle()
        --         -- end, { desc = "DAP: Toggle UI" })
        --     end,
        -- },
        {
            "igorlfs/nvim-dap-view",
            keys = {
                { "<leader>dU", "<cmd>DapViewToggle<cr>", mode = { "n" }, desc = "Toggle Dup view" },
            },
        },
        { "esmuellert/codediff.nvim" },
        {
            "NeogitOrg/neogit",
            lazy = true,
            dependencies = {},
            cmd = "Neogit",
            keys = {
                { "<leader>gG", "<cmd>Neogit<cr>", desc = "Show Neogit UI" },
            },
        },
        { "niuiic/omega.nvim", lazy = false, priority = 1000 },
        {
            "niuiic/translate.nvim",
            lazy = false,
            keys = {
                { "<leader>ts", translate_to_ru("open_float"), mode = { "n", "x" }, desc = "Translate selection" },
                { "<leader>tr", translate_to_ru("replace"), mode = { "x" }, desc = "Translate and replace selection" },
            },
        },
        {
            "dmtrKovalenko/fff.nvim",
            build = function()
                -- downloads a prebuilt binary or falls back to cargo build
                require("fff.download").download_or_build_binary()
            end,
            -- for nixos:
            -- build = "nix run .#release",
            opts = {},
            lazy = false, -- the plugin lazy-initialises itself
            keys = {
                {
                    "<leader><leader>",
                    function()
                        require("fff").find_files()
                    end,
                    desc = "FFFind files",
                },
                {
                    "<leader>/",
                    function()
                        require("fff").live_grep()
                    end,
                    desc = "LiFFFe grep",
                },
                -- { "fz",
                --   function() require('fff').live_grep({ grep = { modes = { 'fuzzy', 'plain' } } }) end,
                --   desc = 'Live fffuzy grep',
                -- },
                {
                    "<leader>sw",
                    function()
                        require("fff").live_grep({ query = vim.fn.expand("<cword>") })
                    end,
                    desc = "Search current word",
                },
            },
        },
        { "mikavilpas/yazi.nvim" },
        -- {
        --     "goldos24/rainbow-variables-nvim",
        --     config = function(plugin)
        --         require("rainbow-variables-nvim").start_with_config({
        --             semantic_background_colors = false,
        --             reduce_color_collisions = true,
        --         })
        --     end,
        -- },
        -- lua/plugins/rose-pine.lua
        {
            "rose-pine/neovim",
            name = "rose-pine",
            config = function()
                -- vim.cmd("colorscheme rose-pine")
            end,

            opts = {
                variant = "auto",
                dark_variant = "main",
                enable = {
                    terminal = true,
                    legacy_highlights = false,
                    migrations = true,
                },
                styles = {
                    bold = true,
                    italic = true,
                    transparency = false,
                },
                groups = {
                    border = "muted",
                    link = "iris",
                    panel = "surface",

                    error = "love",
                    hint = "iris",
                    info = "foam",
                    note = "pine",
                    todo = "rose",
                    warn = "gold",

                    git_add = "foam",
                    git_change = "rose",
                    git_delete = "love",
                    git_dirty = "rose",
                    git_ignore = "muted",
                    git_merge = "iris",
                    git_rename = "pine",
                    git_stage = "iris",
                    git_text = "rose",
                    git_untracked = "subtle",

                    h1 = "iris",
                    h2 = "foam",
                    h3 = "rose",
                    h4 = "gold",
                    h5 = "pine",
                    h6 = "foam",
                },
            },
        },
        {
            "HiPhish/rainbow-delimiters.nvim",
            config = function()
                -- require("rainbow-delimiters.setup").setup({
                -- -- Здесь можно указать настройки
                -- })
            end,
        },

        -- {
        --   -- "brenton-leighton/multiple-cursors.nvim",
        --   -- opts = {},  -- This causes the plugin setup function to be called
        --   -- keys = {
        --   --   -- {"<C-j>", "<Cmd>MultipleCursorsAddDown<CR>", mode = {"n", "x"}, desc = "Add cursor and move down"},
        --   --   -- {"<C-k>", "<Cmd>MultipleCursorsAddUp<CR>", mode = {"n", "x"}, desc = "Add cursor and move up"},
        --   --   --
        --   --   -- {"<C-Up>", "<Cmd>MultipleCursorsAddUp<CR>", mode = {"n", "i", "x"}, desc = "Add cursor and move up"},
        --   --   -- {"<C-Down>", "<Cmd>MultipleCursorsAddDown<CR>", mode = {"n", "i", "x"}, desc = "Add cursor and move down"},
        --   --   --
        --   --   -- {"<C-LeftMouse>", "<Cmd>MultipleCursorsMouseAddDelete<CR>", mode = {"n", "i"}, desc = "Add or remove cursor"},
        --   --
        --   --   {"<Leader>ma", "<Cmd>MultipleCursorsAddVisualArea<CR>", mode = {"x"}, desc = "Add cursors to the lines of the visual area"},
        --   --
        --   --   {"<Leader>mc", "<Cmd>MultipleCursorsAddMatches<CR>", mode = {"n", "x"}, desc = "Add cursors to cword"},
        --   --   {"<Leader>mA", "<Cmd>MultipleCursorsAddMatchesV<CR>", mode = {"n", "x"}, desc = "Add cursors to cword in previous area"},
        --   --
        --   --   {"<Leader>md", "<Cmd>MultipleCursorsAddJumpNextMatch<CR>", mode = {"n", "x"}, desc = "Add cursor and jump to next cword"},
        --   --   {"<Leader>mD", "<Cmd>MultipleCursorsJumpNextMatch<CR>", mode = {"n", "x"}, desc = "Jump to next cword"},
        --   --
        --   --   {"<Leader>l", "<Cmd>MultipleCursorsLock<CR>", mode = {"n", "x"}, desc = "Lock virtual cursors"},
        --   -- },
        --
        --   -- "mg979/vim-visual-multi",
        --   -- keys = {
        --   --   { "g<C-c>", mode = "n", "<CMD>VMCreateCursor<CR>", desc = "Create cursor" },
        --   --   { "<C-n>", mode = "n", "<CMD>VMNext<CR>", desc = "Next match" },
        --   --   { "<C-p>", mode = "n", "<CMD>VMPrevious<CR>", desc = "Previous match" },
        --   -- },
        -- },
        {
            "Civitasv/cmake-tools.nvim",
            opts = {},
            keys = {
                { "<leader>cc", "", mode = { "n", "x" }, desc = "CMake" },
                { "<leader>ccb", "<Cmd>CMakeBuild<CR>", mode = { "n", "x" }, desc = "CMake build" },
                { "<leader>cc", "", mode = { "n", "x" }, desc = "CMake selected" },
                { "<leader>ccc", "<Cmd>CMakeSelectCwd<CR>", mode = { "n", "x" }, desc = "CMake select cwd" },
                { "<leader>ccp", "<Cmd>CMakeSelectConfigurePreset<CR>", mode = { "n", "x" }, desc = "CMake configure presets" },
                { "<leader>cco", "<Cmd>CMakeSelectBuildPreset<CR>", mode = { "n", "x" }, desc = "CMake build presets" },
                { "<leader>cct", "<Cmd>CMakeSelectBuildTarget<CR>", mode = { "n", "x" }, desc = "CMake build target" },
            },
        },
        {
            "jake-stewart/multicursor.nvim",
            branch = "1.0",
            config = function()
                local mc = require("multicursor-nvim")
                mc.setup()

                -- Основной префикс: <Leader>m
                vim.keymap.set("n", "<leader>m", function()
                    -- print("Multi-cursor commands:\n" ..
                    --       "<leader>mn - next match\n" ..
                    --       "<leader>mN - previous match\n" ..
                    --       "<leader>ma - all matches\n" ..
                    --       "<leader>md - delete cursor\n" ..
                    --       "<leader>mgv - restore cursors\n" ..
                    --       "<leader>ms - split by regex\n" ..
                    --       "<leader>mm - match in selection\n" ..
                    --       "<leader>mi - insert visual\n" ..
                    --       "<leader>mA - append visual\n" ..
                    --       "<leader>mt - transpose forward\n" ..
                    --       "<leader>mT - transpose backward\n" ..
                    --       "<leader>mq - duplicate cursors\n" ..
                    --       "<leader>maa - align columns")
                end, { desc = "Multi-cursor" })

                -- Подкоманды
                vim.keymap.set("n", "<leader>mn", function()
                    mc.searchAddCursor(1)
                end, { desc = "Add cursor to next search result" })
                vim.keymap.set("n", "<leader>mN", function()
                    mc.searchAddCursor(-1)
                end, { desc = "Add cursor to previous search result" })
                vim.keymap.set("n", "<leader>ma", mc.searchAllAddCursors, { desc = "Add cursors to all search results in buffer" })
                vim.keymap.set("n", "<leader>md", mc.deleteCursor, { desc = "Delete current cursor" })
                vim.keymap.set("n", "<leader>mgv", mc.restoreCursors, { desc = "Restore cursors if accidentally cleared" })
                vim.keymap.set("x", "<leader>ms", mc.splitCursors, { desc = "Split visual selection by regex" })
                vim.keymap.set("x", "<leader>mm", mc.matchCursors, { desc = "Match cursors in visual selection by regex" })
                vim.keymap.set("x", "<leader>mi", mc.insertVisual, { desc = "Insert at start of each line in visual selection" })
                vim.keymap.set("x", "<leader>mA", mc.appendVisual, { desc = "Append at end of each line in visual selection" })
                vim.keymap.set("x", "<leader>mt", function()
                    mc.transposeCursors(1)
                end, { desc = "Rotate text forward between cursors" })
                vim.keymap.set("x", "<leader>mT", function()
                    mc.transposeCursors(-1)
                end, { desc = "Rotate text backward between cursors" })
                vim.keymap.set({ "n", "x" }, "<leader>mq", mc.duplicateCursors, { desc = "Duplicate all cursors and disable originals" })
                vim.keymap.set("n", "<leader>mal", mc.alignCursors, { desc = "Align all cursors to same column" })

                vim.keymap.set({ "n", "x" }, "<c-n>", function()
                    mc.matchAddCursor(1)
                end)
                vim.keymap.set({ "n", "x" }, "<c-s>", function()
                    mc.matchSkipCursor(1)
                end)
                vim.keymap.set({ "n", "x" }, "<c-a>", mc.matchAllAddCursors)

                mc.addKeymapLayer(function(layerSet)
                    -- Select a different cursor as the main one.
                    layerSet({ "n", "x" }, "<c-left>", mc.prevCursor)
                    layerSet({ "n", "x" }, "<c-right>", mc.nextCursor)

                    -- Delete the main cursor.
                    layerSet({ "n", "x" }, "<leader>x", mc.deleteCursor)

                    -- Enable and clear cursors using escape.
                    layerSet("n", "<esc>", function()
                        if not mc.cursorsEnabled() then
                            mc.enableCursors()
                        else
                            mc.clearCursors()
                        end
                    end)
                end)

                -- Customize how cursors look.
                local hl = vim.api.nvim_set_hl
                hl(0, "MultiCursorCursor", { reverse = true })
                hl(0, "MultiCursorVisual", { link = "Visual" })
                hl(0, "MultiCursorSign", { link = "SignColumn" })
                hl(0, "MultiCursorMatchPreview", { link = "Search" })
                hl(0, "MultiCursorDisabledCursor", { reverse = true })
                hl(0, "MultiCursorDisabledVisual", { link = "Visual" })
                hl(0, "MultiCursorDisabledSign", { link = "SignColumn" })
            end,
        },
        {
            "scottmckendry/cyberdream.nvim",
            lazy = false,
            priority = 1000,
            config = function(plugin)
                -- vim.cmd.colorscheme("cyberdream")
            end,
        },
        {
            "Mofiqul/vscode.nvim",
            lazy = false,
            priority = 1000,
            config = function(plugin)
                -- Override highlight groups (see ./lua/vscode/theme.lua)
                -- vim.cmd.colorscheme("vscode")
            end,
            opts = {
                group_overrides = {
                    -- this supports the same val table as vim.api.nvim_set_hl
                    -- use colors from this colorscheme by requiring vscode.colors!
                },
            },
        },
        -- {
        --     "rktjmp/lush.nvim",
        --     config = function()
        --         local lush = require("lush")
        --         local base = require("vscode") -- если тема доступна как модуль
        --         base.PreProc = { fg = lush.hsl("#88C0D0"), gui = "bold" }
        --         require("lush")(base)
        --     end,
        -- },
        {
            "mellow-theme/mellow.nvim",
            lazy = false,
            config = function(plugin)
                -- vim.cmd.colorscheme("mellow")
            end,
        },
        {
            "vague-theme/vague.nvim",
            lazy = false, -- make sure we load this during startup if it is your main colorscheme
            priority = 1000, -- make sure to load this before all the other plugins
            config = function()
                -- NOTE: you do not need to call setup if you don't want to.
                require("vague").setup({
                    -- optional configuration here
                })
                -- vim.cmd("colorscheme vague")
            end,
        },
        {
            "rebelot/kanagawa.nvim",
            priority = 1000,
            lazy = false,

            config = function(plugin)
                vim.cmd.colorscheme("kanagawa")
            end,
        },
        { "yorumicolors/yorumi.nvim", priority = 1000, lazy = false },
        {
            "catppuccin/nvim",
            name = "catppuccin",
            priority = 1000,
            lazy = false,
            config = function(plugin)
                --     vim.cmd.colorscheme("catppuccin-nvim")
            end,
        },
    }
end

-- every spec file under the "plugins" directory will be loaded automatically by lazy.nvim
--
-- In your plugin files, you can:
-- * add extra plugins
-- * disable/enabled LazyVim plugins
-- * override the configuration of LazyVim plugins
return {
    -- add gruvbox
    {
        "baliestri/aura-theme",
        lazy = false,
        priority = 1000,
        config = function(plugin)
            vim.opt.rtp:append(plugin.dir .. "/packages/neovim")
            vim.cmd([[colorscheme aura-dark]])
        end,
    },

    -- Configure LazyVim to load gruvbox
    {
        "LazyVim/LazyVim",
        opts = {
            colorscheme = "gruvbox",
        },
    },

    -- change trouble config
    {
        "folke/trouble.nvim",
        -- opts will be merged with the parent spec
        opts = { use_diagnostic_signs = true },
    },

    -- disable trouble
    { "folke/trouble.nvim", enabled = false },

    -- override nvim-cmp and add cmp-emoji
    {
        "hrsh7th/nvim-cmp",
        dependencies = { "hrsh7th/cmp-emoji" },
        ---@param opts cmp.ConfigSchema
        opts = function(_, opts)
            table.insert(opts.sources, { name = "emoji" })
        end,
    },

    -- change some telescope options and a keymap to browse plugin files
    {
        "nvim-telescope/telescope.nvim",
        keys = {
      -- add a keymap to browse plugin files
      -- stylua: ignore
      {
        "<leader>fp",
        function() require("telescope.builtin").find_files({ cwd = require("lazy.core.config").options.root }) end,
        desc = "Find Plugin File",
      },
        },
        -- change some options
        opts = {
            defaults = {
                layout_strategy = "horizontal",
                layout_config = { prompt_position = "top" },
                sorting_strategy = "ascending",
                winblend = 0,
            },
        },
    },

    -- add pyright to lspconfig
    {
        "neovim/nvim-lspconfig",
        ---@class PluginLspOpts
        opts = {
            ---@type lspconfig.options
            servers = {
                -- pyright will be automatically installed with mason and loaded with lspconfig
                pyright = {},
            },
        },
    },

    -- add tsserver and setup with typescript.nvim instead of lspconfig
    {
        "neovim/nvim-lspconfig",
        dependencies = {
            "jose-elias-alvarez/typescript.nvim",
            init = function()
                require("lazyvim.util").lsp.on_attach(function(_, buffer)
          -- stylua: ignore
          vim.keymap.set( "n", "<leader>co", "TypescriptOrganizeImports", { buffer = buffer, desc = "Organize Imports" })
                    vim.keymap.set("n", "<leader>cR", "TypescriptRenameFile", { desc = "Rename File", buffer = buffer })
                end)
            end,
        },
        ---@class PluginLspOpts
        opts = {
            ---@type lspconfig.options
            servers = {
                -- tsserver will be automatically installed with mason and loaded with lspconfig
                tsserver = {},
            },
            -- you can do any additional lsp server setup here
            -- return true if you don't want this server to be setup with lspconfig
            ---@type table<string, fun(server:string, opts:_.lspconfig.options):boolean?>
            setup = {
                -- example to setup with typescript.nvim
                tsserver = function(_, opts)
                    require("typescript").setup({ server = opts })
                    return true
                end,
                -- Specify * to use this function as a fallback for any server
                -- ["*"] = function(server, opts) end,
            },
        },
    },

    -- for typescript, LazyVim also includes extra specs to properly setup lspconfig,
    -- treesitter, mason and typescript.nvim. So instead of the above, you can use:
    { import = "lazyvim.plugins.extras.lang.typescript" },

    -- add more treesitter parsers
    {
        "nvim-treesitter/nvim-treesitter",
        opts = {
            ensure_installed = {
                "bash",
                "html",
                "javascript",
                "json",
                "lua",
                "markdown",
                "markdown_inline",
                "python",
                "query",
                "regex",
                "tsx",
                "typescript",
                "vim",
                "yaml",
            },
        },
    },

    -- since `vim.tbl_deep_extend`, can only merge tables and not lists, the code above
    -- would overwrite `ensure_installed` with the new value.
    -- If you'd rather extend the default config, use the code below instead:
    {
        "nvim-treesitter/nvim-treesitter",
        opts = function(_, opts)
            -- add tsx and treesitter
            vim.list_extend(opts.ensure_installed, {
                "tsx",
                "typescript",
            })
        end,
    },

    -- the opts function can also be used to change the default opts:
    {
        "nvim-lualine/lualine.nvim",
        event = "VeryLazy",
        opts = function(_, opts)
            table.insert(opts.sections.lualine_x, {
                function()
                    return "😄"
                end,
            })
        end,
    },

    -- or you can return new options to override all the defaults
    {
        "nvim-lualine/lualine.nvim",
        event = "VeryLazy",
        opts = function()
            return {
                --[[add your custom lualine config here]]
            }
        end,
    },

    -- use mini.starter instead of alpha
    { import = "lazyvim.plugins.extras.ui.mini-starter" },

    -- add jsonls and schemastore packages, and setup treesitter for json, json5 and jsonc
    { import = "lazyvim.plugins.extras.lang.json" },

    -- add any tools you want to have installed below
    {
        "williamboman/mason.nvim",
        opts = {
            ensure_installed = {
                "stylua",
                "shellcheck",
                "shfmt",
                "flake8",
            },
        },
    },
}
